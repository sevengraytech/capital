from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class VisitorLogOut(BaseModel):
    id: int
    ip_address: str
    location: Optional[str]
    user_agent: Optional[str]
    path: Optional[str]
    method: Optional[str]
    user_id: Optional[int]
    created_at: Optional[datetime]


class PaginatedVisitorLogs(BaseModel):
    items: list[VisitorLogOut]
    total: int
    page: int
    pages: int
    page_size: int

