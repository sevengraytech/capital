from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, Transaction
from backend.schemas.schemas import PaginatedTransactions, TransactionOut
from typing import Optional
import math

router = APIRouter(prefix="/transactions", tags=["Transactions"])

@router.get("", response_model=PaginatedTransactions)
def get_transactions(
    page: int = Query(1, ge=1),
    per_page: int = Query(10, ge=1, le=50),
    type_filter: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Transaction).filter(Transaction.user_id == current_user.id)
    if type_filter:
        query = query.filter(Transaction.type == type_filter)
    total = query.count()
    items = query.order_by(Transaction.created_at.desc()).offset((page - 1) * per_page).limit(per_page).all()
    return {
        "items": [TransactionOut.from_orm(t) for t in items],
        "total": total,
        "page": page,
        "pages": max(1, math.ceil(total / per_page)),
        "page_size": per_page
    }
