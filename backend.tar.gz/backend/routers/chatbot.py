"""
Chatbot router
--------------
• POST /chatbot/message          — FAQ bot (no auth required)
• POST /chatbot/support          — Send a message to admin  (auth required)
• GET  /chatbot/support          — Get conversation history  (auth required)
• GET  /chatbot/support/unread   — Count unread admin replies (auth required)
• POST /chatbot/support/read     — Mark admin messages as read (auth required)

Admin-only:
• GET  /chatbot/admin/threads           — List all user conversations
• POST /chatbot/admin/reply/{user_id}   — Reply to a specific user
"""

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, SupportMessage

router = APIRouter(prefix="/chatbot", tags=["Chatbot"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class ChatMessageIn(BaseModel):
    message: str


class ChatMessageOut(BaseModel):
    reply: str


class SupportMessageIn(BaseModel):
    message: str


class SupportMessageOut(BaseModel):
    id: int
    sender: str        # "user" or "admin"
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UnreadCount(BaseModel):
    unread: int


# ── Helper ────────────────────────────────────────────────────────────────────

def _normalize(s: str) -> str:
    return (s or "").strip().lower()


# ── FAQ Bot (public) ──────────────────────────────────────────────────────────

@router.post("/message", response_model=ChatMessageOut)
def chatbot_message(data: ChatMessageIn) -> ChatMessageOut:
    msg = _normalize(data.message)

    if not msg:
        return ChatMessageOut(reply="Type a question and I'll help. Examples: 'How do I deposit?', 'What is KYC?', 'How do withdrawals work?'")

    if any(k in msg for k in ["deposit", "fund", "funds", "add money", "make a deposit", "btc wallet", "usdt wallet", "wallet address"]):
        return ChatMessageOut(
            reply=(
                "To deposit: 1) Log in to your account. 2) Go to the Deposit screen. 3) Choose your crypto (BTC/USDT). "
                "4) Copy your unique wallet address and send funds externally. "
                "After admin verification, your deposit will be marked completed and your balance updates."
            )
        )

    if any(k in msg for k in ["withdraw", "withdrawal", "cash out", "send to my wallet", "payout"]):
        return ChatMessageOut(
            reply=(
                "To withdraw: 1) Log in. 2) Open the Wallet/Withdraw screen. 3) Enter the amount and your destination wallet address. "
                "Withdrawals are processed after review. If a withdrawal is rejected, the amount is refunded."
            )
        )

    if any(k in msg for k in ["kyc", "verify", "verification", "passport", "drivers license", "national id", "utility bill"]):
        return ChatMessageOut(
            reply=(
                "KYC is identity verification. Submit documents in the KYC screen (passport / drivers license / national id / utility bill). "
                "Review typically takes 1–24 hours. You cannot make transactions until KYC is approved."
            )
        )

    if any(k in msg for k in ["plan", "plans", "roi", "daily roi", "earnings", "profit"]):
        return ChatMessageOut(
            reply=(
                "Choose a plan based on your timeframe and risk preference. In general, higher plans target higher daily ROI. "
                "Your investment produces daily profits; principal is returned based on the plan duration. "
                "If you tell me your target (e.g., 'I want safer and short term'), I can suggest which plan fits."
            )
        )

    if any(k in msg for k in ["scam", "recovery", "claim", "fraud", "stolen", "chargeback"]):
        return ChatMessageOut(
            reply=(
                "Scam recovery: submit a recovery report from your dashboard. Provide a detailed case description (minimum 50 characters), "
                "and include relevant information (email/mobile, scam type, amount invested). Our team reviews and contacts you."
            )
        )

    if any(k in msg for k in ["login", "sign in", "password", "reset password", "forgot"]):
        return ChatMessageOut(
            reply=(
                "For login help: use the Login page. If you forgot your password, open the Reset Password page to set a new one. "
                "If you're locked out, try again after a few minutes and ensure email/password are correct."
            )
        )

    if any(k in msg for k in ["contact", "support", "help", "agent", "human", "admin", "talk to someone", "live chat"]):
        return ChatMessageOut(
            reply=(
                "To reach our support team directly, log in and use the **Live Support** tab in this chat panel. "
                "Your message will be sent to an admin who will reply as soon as possible. "
                "Alternatively you can also try asking me — I can help with deposits, withdrawals, KYC, and investment plans."
            )
        )

    return ChatMessageOut(
        reply=(
            "I'm a customer assistant bot. I can help with:\n"
            "• Deposits & wallet addresses\n"
            "• Withdrawals & processing\n"
            "• KYC verification\n"
            "• Investment plans & ROI\n"
            "• Scam recovery claims\n\n"
            "Need to speak to a person? Use the **Live Support** tab to message an admin directly."
        )
    )


# ── Live Support — User endpoints (auth required) ─────────────────────────────

@router.post("/support", response_model=SupportMessageOut, status_code=status.HTTP_201_CREATED)
def send_support_message(
    data: SupportMessageIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """User sends a message to admin support."""
    text = data.message.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")
    if len(text) > 2000:
        raise HTTPException(status_code=400, detail="Message too long (max 2000 characters).")

    msg = SupportMessage(user_id=current_user.id, sender="user", message=text)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg


@router.get("/support", response_model=List[SupportMessageOut])
def get_support_history(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Return full message history for the current user."""
    return (
        db.query(SupportMessage)
        .filter(SupportMessage.user_id == current_user.id)
        .order_by(SupportMessage.created_at.asc())
        .all()
    )


@router.get("/support/unread", response_model=UnreadCount)
def get_unread_count(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Count unread admin replies for the current user."""
    count = (
        db.query(SupportMessage)
        .filter(
            SupportMessage.user_id == current_user.id,
            SupportMessage.sender == "admin",
            SupportMessage.is_read == False,
        )
        .count()
    )
    return {"unread": count}


@router.post("/support/read", status_code=status.HTTP_204_NO_CONTENT)
def mark_messages_read(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Mark all admin messages in this user's thread as read."""
    db.query(SupportMessage).filter(
        SupportMessage.user_id == current_user.id,
        SupportMessage.sender == "admin",
        SupportMessage.is_read == False,
    ).update({"is_read": True})
    db.commit()


# ── Admin endpoints ───────────────────────────────────────────────────────────

def _require_admin(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required.")
    return current_user


class AdminThread(BaseModel):
    user_id: int
    user_email: str
    user_name: str
    last_message: str
    last_message_at: datetime
    unread_count: int


@router.get("/admin/threads", response_model=List[AdminThread])
def admin_list_threads(
    db: Session = Depends(get_db),
    admin: User = Depends(_require_admin),
):
    """List all users who have open support conversations, newest first."""
    from sqlalchemy import func as sqlfunc

    # Get last message per user
    subq = (
        db.query(
            SupportMessage.user_id,
            sqlfunc.max(SupportMessage.id).label("last_id"),
        )
        .group_by(SupportMessage.user_id)
        .subquery()
    )

    rows = (
        db.query(SupportMessage, User)
        .join(subq, SupportMessage.id == subq.c.last_id)
        .join(User, User.id == SupportMessage.user_id)
        .order_by(SupportMessage.created_at.desc())
        .all()
    )

    threads = []
    for msg, user in rows:
        unread = (
            db.query(SupportMessage)
            .filter(
                SupportMessage.user_id == user.id,
                SupportMessage.sender == "user",
                SupportMessage.is_read == False,
            )
            .count()
        )
        threads.append(
            AdminThread(
                user_id=user.id,
                user_email=user.email,
                user_name=user.full_name,
                last_message=msg.message[:120],
                last_message_at=msg.created_at,
                unread_count=unread,
            )
        )
    return threads


@router.get("/admin/thread/{user_id}", response_model=List[SupportMessageOut])
def admin_get_thread(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(_require_admin),
):
    """Get full conversation with a specific user. Marks user messages as read."""
    # Mark user messages as read by admin
    db.query(SupportMessage).filter(
        SupportMessage.user_id == user_id,
        SupportMessage.sender == "user",
        SupportMessage.is_read == False,
    ).update({"is_read": True})
    db.commit()

    return (
        db.query(SupportMessage)
        .filter(SupportMessage.user_id == user_id)
        .order_by(SupportMessage.created_at.asc())
        .all()
    )


@router.delete("/admin/thread/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def admin_delete_thread(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(_require_admin),
):
    """Delete the entire support conversation for a user."""
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found.")
    db.query(SupportMessage).filter(SupportMessage.user_id == user_id).delete()
    db.commit()


@router.delete("/admin/message/{message_id}", status_code=status.HTTP_204_NO_CONTENT)
def admin_delete_message(
    message_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(_require_admin),
):
    """Delete a single message by ID."""
    msg = db.query(SupportMessage).filter(SupportMessage.id == message_id).first()
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found.")
    db.delete(msg)
    db.commit()


@router.post("/admin/reply/{user_id}", response_model=SupportMessageOut, status_code=status.HTTP_201_CREATED)
def admin_reply(
    user_id: int,
    data: SupportMessageIn,
    db: Session = Depends(get_db),
    admin: User = Depends(_require_admin),
):
    """Admin replies to a user's support thread."""
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found.")

    text = data.message.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    msg = SupportMessage(user_id=user_id, sender="admin", message=text, is_read=False)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg
