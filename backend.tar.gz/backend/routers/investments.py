from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.core.email_service import notify_profit
from backend.models.models import (User, Investment, InvestmentPlan, InvestmentStatus,
                                    Transaction, TransactionType, TransactionStatus,
                                    ProfitLog, KYCStatus)
from backend.schemas.schemas import InvestmentPlanOut, InvestRequest, ClaimInvestmentRequest, InvestmentOut
from datetime import datetime, timedelta
from typing import List
import secrets, threading

router = APIRouter(prefix="/investments", tags=["Investments"])

def kyc_required(current_user: User):
    if current_user.kyc_status != KYCStatus.APPROVED:
        raise HTTPException(status_code=403, detail={
            "code": "KYC_REQUIRED",
            "message": "KYC verification required before investing.",
            "kyc_status": current_user.kyc_status.value
        })

@router.get("/plans", response_model=List[InvestmentPlanOut])
def get_plans(db: Session = Depends(get_db)):
    return db.query(InvestmentPlan).filter(InvestmentPlan.is_active == True).all()

@router.post("/invest")
def invest(data: InvestRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    kyc_required(current_user)
    plan = db.query(InvestmentPlan).filter(InvestmentPlan.id == data.plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    if data.amount < plan.min_amount:
        raise HTTPException(status_code=400, detail=f"Minimum investment is ${plan.min_amount}")
    if data.amount > plan.max_amount:
        raise HTTPException(status_code=400, detail=f"Maximum investment is ${plan.max_amount}")
    if data.amount > current_user.balance:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    end_date = datetime.utcnow() + timedelta(days=plan.duration_days)
    investment = Investment(
        user_id=current_user.id, plan_id=plan.id,
        amount=data.amount, end_date=end_date, status=InvestmentStatus.ACTIVE
    )
    current_user.balance -= data.amount
    current_user.total_invested += data.amount
    tx = Transaction(
        user_id=current_user.id, type=TransactionType.INVESTMENT,
        amount=data.amount, status=TransactionStatus.COMPLETED,
        description=f"Investment in {plan.name}",
        reference="INV-" + secrets.token_hex(6).upper()
    )
    db.add(investment); db.add(tx)
    db.commit(); db.refresh(investment)
    return {"message": "Investment created", "investment_id": investment.id}

@router.get("/my", response_model=List[InvestmentOut])
def get_my_investments(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Investment).filter(Investment.user_id == current_user.id)\
        .order_by(Investment.start_date.desc()).all()

@router.post("/claim")
def claim_investment(data: ClaimInvestmentRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    kyc_required(current_user)
    inv = db.query(Investment).filter(
        Investment.id == data.investment_id, Investment.user_id == current_user.id
    ).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Investment not found")
    if inv.status != InvestmentStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Investment is not active")
    if inv.end_date and datetime.utcnow() < inv.end_date:
        raise HTTPException(status_code=400, detail="Investment has not matured yet")

    inv.status = InvestmentStatus.COMPLETED
    current_user.balance += inv.amount
    tx = Transaction(
        user_id=current_user.id, type=TransactionType.CLAIM,
        amount=inv.amount, status=TransactionStatus.COMPLETED,
        description=f"Principal claimed — Investment #{inv.id}",
        reference="CLM-" + secrets.token_hex(6).upper()
    )
    db.add(tx); db.commit()
    return {"message": "Claimed", "amount": inv.amount, "new_balance": round(current_user.balance, 2)}

@router.post("/accrue-profits")
def accrue_profits(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    investments = db.query(Investment).filter(
        Investment.user_id == current_user.id,
        Investment.status == InvestmentStatus.ACTIVE
    ).all()

    total_profit = 0.0
    accrued_count = 0
    now = datetime.utcnow()

    for inv in investments:
        last = inv.last_accrual or inv.start_date
        hours_since = (now - last).total_seconds() / 3600
        if hours_since >= 1:
            profit = round(inv.amount * (inv.plan.daily_roi / 100), 4)
            inv.total_profit_earned += profit
            inv.last_accrual = now
            current_user.balance += profit
            current_user.total_profit += profit
            total_profit += profit
            accrued_count += 1

            db.add(ProfitLog(
                user_id=current_user.id, investment_id=inv.id,
                amount=profit, description=f"Daily ROI from {inv.plan.name}"
            ))
            db.add(Transaction(
                user_id=current_user.id, type=TransactionType.PROFIT,
                amount=profit, status=TransactionStatus.COMPLETED,
                description=f"Daily profit — Investment #{inv.id}",
                reference="PRF-" + secrets.token_hex(6).upper()
            ))

    db.commit()

    # Send profit email notification if opted in
    if accrued_count > 0 and current_user.email_notifications:
        from backend.core.database import SessionLocal
        plan_name = investments[0].plan.name if investments else "your plan"
        t = threading.Thread(
            target=notify_profit,
            args=(current_user.email, current_user.full_name, round(total_profit, 4),
                  round(current_user.balance, 2), plan_name, SessionLocal(), current_user.id),
            daemon=True
        )
        t.start()

    return {
        "message": f"Accrued for {accrued_count} investment(s)",
        "total_profit": round(total_profit, 4),
        "new_balance": round(current_user.balance, 2)
    }
