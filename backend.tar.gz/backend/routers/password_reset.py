from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.models.models import User
from backend.core.security import get_password_hash
import secrets
from datetime import datetime, timedelta

from pydantic import BaseModel, EmailStr

router = APIRouter(prefix="/auth", tags=["Authentication"])

# Simple reset token store (demo mode).
# In production, create a PasswordResetToken table.
_RESET_TOKENS: dict[str, dict] = {}

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

# --- Email sending ---
# Reuse existing email service (SMTP or dev logging)
from backend.core.email_service import send_email


def _build_reset_email(token: str) -> tuple[str, str]:
    # Send token via URL so the frontend can call /auth/reset-password using it.
    reset_link = f"http://localhost:8000/reset-password?token={token}"
    subject = "🔐 Password Reset Request"
    body = f"""
<h2>Password Reset Requested</h2>
<p>We received a request to reset your CryptoVault password.</p>
<p><strong>Reset Token:</strong> <span style='font-family:monospace;'>{token}</span></p>
<p>You can reset your password using the link below:</p>
<p><a href='{reset_link}' style='color:#00d4aa;font-weight:700;'>{reset_link}</a></p>
<p>If you did not request this, you can ignore this email.</p>
"""
    return subject, body


@router.post("/forgot-password")
def forgot_password(data: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    # Do not reveal whether email exists
    if not user:
        return {"message": "If that email exists, a reset link has been sent."}

    token = secrets.token_urlsafe(32)
    _RESET_TOKENS[token] = {
        "user_id": user.id,
        "email": user.email,
        "expires_at": datetime.utcnow() + timedelta(hours=1),
    }

    subject, body = _build_reset_email(token)

    # Send (or dev-log) email
    # Use user_id for logging
    send_email(user.email, subject, body, db, user.id, "password_reset")

    return {"message": "If that email exists, a reset link has been sent."}


@router.post("/reset-password")
def reset_password(data: ResetPasswordRequest, db: Session = Depends(get_db)):
    record = _RESET_TOKENS.get(data.token)
    if not record:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    if record["expires_at"] < datetime.utcnow():
        _RESET_TOKENS.pop(data.token, None)
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")

    user = db.query(User).filter(User.id == record["user_id"], User.email == record["email"]).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid token")

    user.hashed_password = get_password_hash(data.new_password)
    db.commit()

    _RESET_TOKENS.pop(data.token, None)

    return {"message": "Password updated successfully"}

