from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.core.email_service import notify_deposit, notify_withdrawal
from backend.models.models import (User, Transaction, TransactionType, TransactionStatus,
                                    Investment, InvestmentStatus, KYCStatus,
                                    KYCSubmission, KYCDocumentType, ClaimBlack, ClaimStatus)
from backend.schemas.schemas import UserOut, DepositRequest, WithdrawRequest, ClaimReportCreate, ClaimReportResponse
import logging
from datetime import datetime, timedelta
import secrets

logger = logging.getLogger(__name__)
from pydantic import BaseModel
from datetime import datetime, timedelta
from fastapi import Body, HTTPException
import secrets, threading, logging

router = APIRouter(prefix="/user", tags=["User"])

def _email_async(fn, *args):
    t = threading.Thread(target=fn, args=args, daemon=True)
    t.start()

def kyc_required(current_user: User):
    """Raise 403 if KYC is not approved."""
    if current_user.kyc_status != KYCStatus.APPROVED:
        raise HTTPException(
            status_code=403,
            detail={
                "code": "KYC_REQUIRED",
                "message": "Identity verification (KYC) required before making transactions.",
                "kyc_status": current_user.kyc_status.value
            }
        )

@router.get("/me", response_model=UserOut)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.get("/overview")
def get_overview(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    active_investments = db.query(Investment).filter(
        Investment.user_id == current_user.id,
        Investment.status == InvestmentStatus.ACTIVE
    ).count()
    return {
        "balance": round(current_user.balance, 2),
        "total_invested": round(current_user.total_invested, 2),
        "total_profit": round(current_user.total_profit, 2),
        "active_investments": active_investments,
        "wallet_address": current_user.wallet_address,
        "btc_wallet_address": getattr(current_user, "btc_wallet_address", None),
        "usdt_wallet_address": getattr(current_user, "usdt_wallet_address", None),

        "kyc_status": current_user.kyc_status.value,
        "is_admin": current_user.is_admin,
        "full_name": current_user.full_name,
        "email": current_user.email,
    }

@router.post("/deposit")
def deposit(data: DepositRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Create a deposit request that requires admin approval.

    - Credits are NOT applied immediately.
    - A user-visible invoice HTML page is generated and returned.
    """
    kyc_required(current_user)

    ref = "DEP-" + secrets.token_hex(6).upper()

    # Create pending transaction (no balance credit yet)
    tx = Transaction(
        user_id=current_user.id,
        type=TransactionType.DEPOSIT,
        amount=data.amount,
        status=TransactionStatus.PENDING,
        description=f"Deposit via {data.crypto_type} (awaiting admin approval)",
        reference=ref,
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)

    # Generate invoice HTML (frontend can open/download it)
    invoice_html = f"""<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
  <title>Invoice {ref}</title>
  <style>
    body{{font-family:Arial,sans-serif;background:#f6f7fb;margin:0;padding:0;color:#111827;}}
    .wrap{{max-width:720px;margin:40px auto;background:#fff;border-radius:16px;border:1px solid #e5e7eb;overflow:hidden;}}
    .header{{padding:28px 30px;background:linear-gradient(135deg,#0a0f1e,#0f1628);color:#fff;}}
    .header h1{{margin:0;font-size:22px;letter-spacing:-0.2px;}}
    .header p{{margin:8px 0 0 0;color:#cbd5e1;font-size:13px;}}
    .content{{padding:26px 30px;}}
    .grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px;}}
    .box{{border:1px solid #e5e7eb;border-radius:12px;padding:14px;}}
    .k{{font-size:12px;color:#6b7280;text-transform:uppercase;letter-spacing:.4px;font-weight:700;}}
    .v{{margin-top:8px;font-size:16px;font-weight:800;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,\"Liberation Mono\",\"Courier New\",monospace;}}
    .amount{{font-size:30px;font-weight:900;color:#00d4aa;}}
    .note{{margin-top:18px;color:#4b5563;line-height:1.6;font-size:14px;}}
    .btn{{display:inline-block;margin-top:16px;padding:12px 18px;background:#00d4aa;color:#051018;text-decoration:none;border-radius:10px;font-weight:800;}}
    .muted{{color:#6b7280;}}
    .sep{{height:1px;background:#e5e7eb;margin:18px 0;}}
  </style>
</head>
<body>
  <div class=\"wrap\">
    <div class=\"header\">
      <h1>CryptoVault Deposit Invoice</h1>
      <p>Your deposit is pending admin approval. Keep this reference.</p>
    </div>
    <div class=\"content\">
      <div class=\"grid\">
        <div class=\"box\">
          <div class=\"k\">Reference</div>
          <div class=\"v\">{ref}</div>
        </div>
        <div class=\"box\">
          <div class=\"k\">Status</div>
          <div class=\"v\">PENDING</div>
        </div>
        <div class=\"box\">
          <div class=\"k\">Amount</div>
          <div class=\"amount\">${data.amount:.2f}</div>
        </div>
        <div class=\"box\">
          <div class=\"k\">Crypto Type</div>
          <div class=\"v\">{data.crypto_type}</div>
        </div>
      </div>

      <div class=\"sep\"></div>

      <div class=\"note\">
        <div><strong>Step 1:</strong> Send funds externally using your deposit wallet address.</div>
        <div style=\"margin-top:8px;\"><span class=\"k\">BTC Wallet</span><div class=\"v\" style=\"margin-top:8px;\">{getattr(current_user,'btc_wallet_address','—') or '—'}</div></div>
        <div style=\"margin-top:8px;\"><span class=\"k\">USDT Wallet</span><div class=\"v\" style=\"margin-top:8px;\">{getattr(current_user,'usdt_wallet_address','—') or '—'}</div></div>
        <div class=\"muted\" style=\"margin-top:14px;\">
          After you send, the admin team will verify and approve your deposit. Once approved, your balance will update.
        </div>
      </div>

      <div class=\"sep\"></div>

      <div class=\"note\">
        <div><strong>Step 2:</strong> Wait for confirmation.</div>
        <div class=\"muted\">You can track the request in your Transactions page.</div>
      </div>

      <a class=\"btn\" href=\"/dashboard\">Go to Dashboard</a>
    </div>
  </div>
</body>
</html>"""

    return {
        "message": "Deposit request submitted. Awaiting admin approval.",
        "reference": ref,
        "amount": data.amount,
        "status": TransactionStatus.PENDING.value,
        "invoice_html": invoice_html,
    }


@router.post("/withdraw")
def withdraw(data: WithdrawRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    kyc_required(current_user)
    if data.amount > current_user.balance:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    if data.amount < 10:
        raise HTTPException(status_code=400, detail="Minimum withdrawal is $10")

    ref = "WIT-" + secrets.token_hex(6).upper()
    current_user.balance -= data.amount
    tx = Transaction(
        user_id=current_user.id,
        type=TransactionType.WITHDRAWAL,
        amount=data.amount,
        status=TransactionStatus.PENDING,
        description=f"Withdrawal to {data.wallet_address[:12]}...",
        reference=ref
    )
    db.add(tx)
    db.commit()

    from backend.core.database import SessionLocal
    _email_async(notify_withdrawal, current_user.email, current_user.full_name,
                 data.amount, ref, SessionLocal(), current_user.id)

    return {"message": "Withdrawal request submitted", "reference": ref,
            "amount": data.amount, "new_balance": round(current_user.balance, 2)}

@router.patch("/notifications")
def toggle_notifications(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    current_user.email_notifications = not current_user.email_notifications
    db.commit()
    return {"email_notifications": current_user.email_notifications}


# ── KYC ─────────────────────────────────────────────────────────────────────

class KYCSubmitData(BaseModel):
    document_type: str
    document_number: str
    full_name: str
    date_of_birth: str
    country: str
    address: str

@router.post("/kyc/submit")
def submit_kyc(data: KYCSubmitData, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.kyc_status == KYCStatus.APPROVED:
        raise HTTPException(status_code=400, detail="KYC already approved")

    doc_type_map = {
        "passport": KYCDocumentType.PASSPORT,
        "drivers_license": KYCDocumentType.DRIVERS_LICENSE,
        "national_id": KYCDocumentType.NATIONAL_ID,
        "utility_bill": KYCDocumentType.UTILITY_BILL,
    }
    doc_type = doc_type_map.get(data.document_type)
    if not doc_type:
        raise HTTPException(status_code=400, detail="Invalid document type")

    existing = db.query(KYCSubmission).filter(KYCSubmission.user_id == current_user.id).first()
    if existing:
        existing.document_type = doc_type
        existing.document_number = data.document_number
        existing.full_name = data.full_name
        existing.date_of_birth = data.date_of_birth
        existing.country = data.country
        existing.address = data.address
        existing.status = KYCStatus.PENDING
        existing.rejection_reason = None
    else:
        sub = KYCSubmission(
            user_id=current_user.id,
            document_type=doc_type,
            document_number=data.document_number,
            full_name=data.full_name,
            date_of_birth=data.date_of_birth,
            country=data.country,
            address=data.address,
        )
        db.add(sub)

    current_user.kyc_status = KYCStatus.PENDING
    db.commit()
    return {"message": "KYC submitted successfully. Review typically takes 1–24 hours.", "status": "pending"}

@router.get("/kyc/status")
def get_kyc_status(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sub = db.query(KYCSubmission).filter(KYCSubmission.user_id == current_user.id).first()
    return {
        "kyc_status": current_user.kyc_status.value,
        "submission": {
            "document_type": sub.document_type.value if sub else None,
            "full_name": sub.full_name if sub else None,
            "country": sub.country if sub else None,
            "submitted_at": sub.submitted_at.isoformat() if sub else None,
            "rejection_reason": sub.rejection_reason if sub else None,
        } if sub else None
    }

@router.post("/scam-report", 
             response_model=ClaimReportResponse,
             status_code=status.HTTP_201_CREATED,
             summary="Submit Scam Recovery Report (User Dashboard)")
def submit_user_scam_report(
    report_data: ClaimReportCreate = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    User dashboard endpoint for scam recovery report submission.
    Reuses existing claimback service logic.
    """
    from backend.services.claim_service import ClaimService
    
    claim_service = ClaimService(db)
    
    try:
        # Quick validation - aligned with schema (min 50 chars)
        if not report_data.case_description or len(report_data.case_description.strip()) < 50:
            raise HTTPException(status_code=400, detail="Case description must be at least 50 characters long")
        
        # Check recent duplicate (24hr cooldown per email/mobile)
        recent_case = db.query(ClaimBlack).filter(
            ClaimBlack.email == report_data.email,
            ClaimBlack.created_at >= datetime.utcnow() - timedelta(hours=24)
        ).first()
        
        if recent_case:
            raise HTTPException(status_code=429, detail="Recent case exists. Team will contact you soon.")
        
        # Generate case ID
        case_id = f"REC-{secrets.token_hex(8).upper()}"
        
        # Create claim (link to current user)
        claim_record = ClaimBlack(
            case_id=case_id,
            first_name=report_data.first_name,
            last_name=report_data.last_name,
            email=report_data.email,
            mobile=report_data.mobile or "",
            country=report_data.country,
            scam_type=report_data.scam_type,
            amount_invested=report_data.amount_invested,
            case_description=report_data.case_description,
            user_id=current_user.id,
            status=ClaimStatus.PENDING,
            created_at=datetime.utcnow()
        )
        
        db.add(claim_record)
        
        # Triage BEFORE commit to persist changes
        claim_service.triage_case(claim_record)
        db.commit()
        db.refresh(claim_record)
        
        # Handle optional evidence_links if provided
        if hasattr(report_data, 'evidence_links') and report_data.evidence_links:
            claim_record.case_description += f"\n\nEvidence Links:\n" + "\n".join(report_data.evidence_links)
        
        logger.info(f"User scam report: {case_id} | ${report_data.amount_invested} | {current_user.email}")
        
        return ClaimReportResponse(
            success=True,
            case_id=case_id,
            message="✅ Case submitted! Recovery team will contact you within 24 hours.",
            status=ClaimStatus.PENDING.value,
            next_steps=["Check email confirmation", "Track in dashboard", "Expect specialist contact"],
            estimated_recovery_time="24-48 hours"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User scam report failed: {e}")
        raise HTTPException(status_code=500, detail="Submission failed. Please try again.")
