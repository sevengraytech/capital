from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    SECRET_KEY: str = "cryptovault-super-secret-key-change-in-production-2024"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    DATABASE_URL: str = "sqlite:///./cryptovault.db"

    # ── Stalwart / SMTP settings ───────────────────────────────────────────
    # Set these in your .env file or docker-compose environment section
    SMTP_HOST: str = "mail.strongnodecapitals.com"   # your Stalwart server host
    SMTP_PORT: int = 587                               # 587 = STARTTLS, 465 = SSL
    SMTP_USER: str = "noreply@strongnodecapitals.com" # Stalwart mailbox user
    SMTP_PASS: str = ""                                # Stalwart mailbox password
    SMTP_FROM: str = "StrongNode Capitals <noreply@strongnodecapitals.com>"
    SMTP_TLS: bool = True                              # True = STARTTLS, False = plain

    # ── App base URL (used in activation links) ────────────────────────────
    APP_BASE_URL: str = "https://strongnodecapitals.com"

    # ── Activation token expiry (hours) ───────────────────────────────────
    ACTIVATION_TOKEN_EXPIRE_HOURS: int = 48

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
