import os
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from backend.core.config import settings

SQLALCHEMY_DATABASE_URL = settings.DATABASE_URL

# For SQLite: ensure the parent directory exists and touch the file so Docker
# doesn't mount it as a directory when the host file is missing.
if SQLALCHEMY_DATABASE_URL.startswith("sqlite"):
    _raw = SQLALCHEMY_DATABASE_URL.replace("sqlite:///", "", 1)
    if _raw and _raw != ":memory:":
        _db_path = Path(_raw)
        _db_path.parent.mkdir(parents=True, exist_ok=True)
        _db_path.touch(exist_ok=True)

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def _sqlite_table_columns(conn, table_name: str) -> set:
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table_name})")
    return {row[1] for row in cur.fetchall()}


def run_sqlite_auto_migrations() -> None:
    """Best-effort SQLite schema upgrades.

    This project historically added columns without migrations.
    When the DB file is older, app startup can fail with:
      sqlite3.OperationalError: no such column: users.<column>

    This function fixes that for known columns by issuing ALTER TABLE
    only when the column is missing.
    """
    import sqlite3

    db_path = engine.url.database
    if not db_path:
        return

    conn = sqlite3.connect(db_path)
    try:
        users_cols = _sqlite_table_columns(conn, "users")

        required_user_columns = [
            ("profile_picture_url", "VARCHAR"),
            ("registration_completed", "BOOLEAN NOT NULL DEFAULT 0"),
            ("activation_token", "VARCHAR"),
            ("activation_token_expires_at", "DATETIME"),
            ("promo_code_used", "VARCHAR"),
            ("referral_code", "VARCHAR"),
            ("referrer_user_id", "INTEGER"),
            ("email_notifications", "BOOLEAN NOT NULL DEFAULT 1"),
            ("phone_notifications", "BOOLEAN NOT NULL DEFAULT 0"),
        ]

        cur = conn.cursor()
        for col_name, col_def in required_user_columns:
            if col_name not in users_cols:
                cur.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_def}")

        # Add support_messages table columns check
        support_tables = _sqlite_table_columns(conn, "sqlite_master")
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='support_messages'")
        if not cur.fetchone():
            cur.execute("""
                CREATE TABLE IF NOT EXISTS support_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id),
                    sender VARCHAR(10) NOT NULL,
                    message TEXT NOT NULL,
                    is_read BOOLEAN DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)

        conn.commit()
    finally:
        conn.close()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
