from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Enum, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import timedelta
from backend.core.database import Base
import enum

class TransactionType(str, enum.Enum):
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    PROFIT = "profit"
    LOAN = "loan"
    LOAN_REPAY = "loan_repay"
    CLAIM = "claim"
    INVESTMENT = "investment"
    BONUS = "bonus"

class TransactionStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class InvestmentStatus(str, enum.Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class LoanStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    REPAID = "repaid"

class KYCStatus(str, enum.Enum):
    NOT_SUBMITTED = "not_submitted"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class KYCDocumentType(str, enum.Enum):
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"
    NATIONAL_ID = "national_id"
    UTILITY_BILL = "utility_bill"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    balance = Column(Float, default=0.0)
    total_invested = Column(Float, default=0.0)
    total_profit = Column(Float, default=0.0)
    wallet_address = Column(String, default="")
    btc_wallet_address = Column(String, default="")
    usdt_wallet_address = Column(String, default="")

    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    kyc_status = Column(Enum(KYCStatus), default=KYCStatus.NOT_SUBMITTED)
    bonus_credited = Column(Boolean, default=False)
    promo_code_used = Column(String, nullable=True)
    email_notifications = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    transactions = relationship("Transaction", back_populates="user")
    investments = relationship("Investment", back_populates="user")
    profit_logs = relationship("ProfitLog", back_populates="user")
    loan_requests = relationship("LoanRequest", back_populates="user")
    kyc_submission = relationship("KYCSubmission", back_populates="user", uselist=False, foreign_keys="KYCSubmission.user_id")

class KYCSubmission(Base):
    __tablename__ = "kyc_submissions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    document_type = Column(Enum(KYCDocumentType), nullable=False)
    document_number = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    date_of_birth = Column(String, nullable=False)
    country = Column(String, nullable=False)
    address = Column(Text, nullable=False)
    front_image_url = Column(String, default="uploaded")
    selfie_url = Column(String, default="uploaded")
    status = Column(Enum(KYCStatus), default=KYCStatus.PENDING)
    rejection_reason = Column(String, nullable=True)
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
    reviewed_at = Column(DateTime(timezone=True), nullable=True)
    reviewed_by = Column(Integer, nullable=True)

    user = relationship("User", back_populates="kyc_submission", foreign_keys=[user_id])

class PromoCode(Base):
    __tablename__ = "promo_codes"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String, unique=True, nullable=False, index=True)
    bonus_amount = Column(Float, default=100.0)
    max_uses = Column(Integer, default=100)
    used_count = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    description = Column(String, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=True)

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(Enum(TransactionType), nullable=False)
    amount = Column(Float, nullable=False)
    status = Column(Enum(TransactionStatus), default=TransactionStatus.PENDING)
    description = Column(String, default="")
    reference = Column(String, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="transactions")

class InvestmentPlan(Base):
    __tablename__ = "investment_plans"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    daily_roi = Column(Float, nullable=False)
    min_amount = Column(Float, nullable=False)
    max_amount = Column(Float, nullable=False)
    duration_days = Column(Integer, nullable=False)
    description = Column(String, default="")
    is_active = Column(Boolean, default=True)

    investments = relationship("Investment", back_populates="plan")

class Investment(Base):
    __tablename__ = "investments"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    plan_id = Column(Integer, ForeignKey("investment_plans.id"), nullable=False)
    amount = Column(Float, nullable=False)
    status = Column(Enum(InvestmentStatus), default=InvestmentStatus.ACTIVE)
    start_date = Column(DateTime(timezone=True), server_default=func.now())
    end_date = Column(DateTime(timezone=True), nullable=True)
    last_accrual = Column(DateTime(timezone=True), server_default=func.now())
    total_profit_earned = Column(Float, default=0.0)

    user = relationship("User", back_populates="investments")
    plan = relationship("InvestmentPlan", back_populates="investments")
    profit_logs = relationship("ProfitLog", back_populates="investment")

class ProfitLog(Base):
    __tablename__ = "profit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    investment_id = Column(Integer, ForeignKey("investments.id"), nullable=False)
    amount = Column(Float, nullable=False)
    date = Column(DateTime(timezone=True), server_default=func.now())
    description = Column(String, default="Daily ROI profit")

    user = relationship("User", back_populates="profit_logs")
    investment = relationship("Investment", back_populates="profit_logs")

class LoanRequest(Base):
    __tablename__ = "loan_requests"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Float, nullable=False)
    interest_rate = Column(Float, default=5.0)
    duration_months = Column(Integer, default=12, nullable=False)
    monthly_payment = Column(Float, default=0.0)
    total_repaid = Column(Float, default=0.0)
    remaining_balance = Column(Float, default=0.0)
    due_date = Column(DateTime(timezone=True), nullable=True)
    status = Column(Enum(LoanStatus), default=LoanStatus.PENDING)
    purpose = Column(String, default="")
    approved_at = Column(DateTime(timezone=True), nullable=True)
    repaid_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="loan_requests")

class EmailNotificationLog(Base):
    __tablename__ = "email_notification_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    recipient_email = Column(String, nullable=False)
    subject = Column(String, nullable=False)
    body = Column(Text, nullable=False)
    sent_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String, default="sent")
    notification_type = Column(String, default="general")

class AdminSettings(Base):
    __tablename__ = "admin_settings"
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String, unique=True, nullable=False)
    value = Column(Text, nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now())


class ClaimStatus(str, enum.Enum):
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    IN_PROGRESS = "in_progress"
    RECOVERED = "recovered"
    CLOSED = "closed"
    REJECTED = "rejected"

class ClaimBlack(Base):
    __tablename__ = "claim_black"
    
    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(String(50), unique=True, index=True, nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), index=True, nullable=False)
    mobile = Column(String(20), index=True)
    country = Column(String(100), nullable=False)
    scam_type = Column(String(100), nullable=False)
    amount_invested = Column(Float, nullable=False)
    amount_recovered = Column(Float, default=0.0)
    case_description = Column(Text, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    status = Column(Enum(ClaimStatus), default=ClaimStatus.PENDING.value)
    priority = Column(Integer, default=1)  # 1=low, 5=high
    assigned_specialist = Column(String(100))
    recovery_days = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # user = relationship("User", back_populates="claims") # Disabled to avoid bidirectional mapping issue


    