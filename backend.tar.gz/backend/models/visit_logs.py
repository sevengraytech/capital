from sqlalchemy import Column, Integer, String, DateTime, Text
from backend.core.database import Base
from sqlalchemy.sql import func


class VisitorLog(Base):
    """Stores visitor info for admin analytics.

    Note: Location is stored as a free-form text string (e.g. "Berlin, DE").
    For now we capture IP + optional coarse location (if GeoIP lookup is added later).
    """

    __tablename__ = "visitor_logs"

    id = Column(Integer, primary_key=True, index=True)

    # user linkage (optional)
    user_id = Column(Integer, nullable=True, index=True)

    # request metadata
    ip_address = Column(String(64), nullable=False, index=True)
    location = Column(Text, nullable=True)  # free-form text
    user_agent = Column(Text, nullable=True)

    # path / context
    path = Column(Text, nullable=True)
    method = Column(String(10), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

